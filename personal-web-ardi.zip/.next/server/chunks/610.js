"use strict";
exports.id = 610;
exports.ids = [610];
exports.modules = {

/***/ 4275:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/cancel.ba9b29b7.svg","height":512,"width":512});

/***/ }),

/***/ 6029:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/img-mobile.fb83fefe.jpg","height":300,"width":300,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAEAAwAAAAAAAAAAAAAAAAARACNC/9oACAEBAAE/ALHJP//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 8212:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Address = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                className: "open-sans-font custom-span-contact position-relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                        className: "fa fa-map position-absolute"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "d-block",
                        children: "Address"
                    }),
                    "Taman Kedaung. Kedaung Pamulang Tangerang Selatan, Banten, Indonesia"
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                className: "open-sans-font custom-span-contact position-relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                        className: "fa fa-envelope-open position-absolute"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "d-block",
                        children: "Mail me"
                    }),
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "mailto:steve@mail.com",
                        children: "ardi.iradat@gmail.com"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Address);


/***/ }),

/***/ 6047:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7163);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_emailjs_browser__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_3__]);
react_toastify__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Contact = ()=>{
    const form = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const sendEmail = (e)=>{
        e.preventDefault();
        _emailjs_browser__WEBPACK_IMPORTED_MODULE_2___default().sendForm("service_n4mkhz9", "template_ugoztxr", form.current, "user_vYmDSd9PwIuRXUQEDjYwN").then((result)=>{
            console.log(result);
            react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.success("Message Sent Successfully!", {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined
            });
            document.getElementById("myForm").reset();
        }, (error)=>{
            react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.error("Ops Message Not Sent!", {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined
            });
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
            id: "myForm",
            className: "contactform",
            ref: form,
            onSubmit: sendEmail,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12 col-md-6",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "form-group",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "text",
                                name: "name",
                                placeholder: "YOUR NAME",
                                required: true
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12 col-md-6",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "form-group",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "email",
                                name: "user_email",
                                placeholder: "YOUR EMAIL",
                                required: true
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12 col-md-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "form-group",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "text",
                                name: "subject",
                                placeholder: "YOUR SUBJECT",
                                required: true
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "form-group",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                name: "message",
                                placeholder: "YOUR MESSAGE",
                                required: true
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            type: "submit",
                            className: "button",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "button-text",
                                    children: "Send Message"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "button-icon fa fa-send"
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Contact);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1690:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);


const SEO = ({ pageTitle  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: pageTitle && `Portofolio Website - ${pageTitle}`
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                    httpEquiv: "x-ua-compatible",
                    content: "ie=edge"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                    name: "description",
                    content: "Generated by create next app"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                    name: "robots",
                    content: "noindex, follow"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                    name: "viewport",
                    content: "width=device-width, initial-scale=1, shrink-to-fit=no"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                    rel: "icon",
                    href: "/favicon.ico"
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SEO);


/***/ }),

/***/ 9830:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const SocialShare = [
    {
        iconName: "fa fa-facebook",
        link: "https://www.facebook.com/"
    },
    {
        iconName: "fa fa-twitter",
        link: "https://twitter.com/"
    },
    {
        iconName: "fa fa-youtube",
        link: "https://www.youtube.com/"
    },
    {
        iconName: "fa fa-dribbble",
        link: "https://dribbble.com/"
    }
];
const Social = ()=>{
    return /*#__PURE__*/ _jsx("ul", {
        className: "social list-unstyled pt-1 mb-5",
        children: SocialShare.map((val, i)=>/*#__PURE__*/ _jsx("li", {
                children: /*#__PURE__*/ _jsx("a", {
                    href: val.link,
                    target: "_blank",
                    rel: "noreferrer",
                    children: /*#__PURE__*/ _jsx("i", {
                        className: val.iconName
                    })
                })
            }, i))
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Social)));


/***/ }),

/***/ 201:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ about)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/components/about/Achievements.jsx


const achievementsContent = [
    {
        title: "4",
        subTitle1: "years of",
        subTitle2: "experience"
    },
    {
        title: "10",
        subTitle1: "completed",
        subTitle2: "projects"
    }
];
const Achievements = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "row",
        children: achievementsContent.map((val, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-6",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "box-stats with-margin",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: "poppins-font position-relative",
                            children: val.title
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: "open-sans-font m-0 position-relative text-uppercase",
                            children: [
                                val.subTitle1,
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "d-block",
                                    children: val.subTitle2
                                })
                            ]
                        })
                    ]
                })
            }, i))
    });
};
/* harmony default export */ const about_Achievements = (Achievements);

;// CONCATENATED MODULE: ./src/components/about/Education.jsx


const educationContent = [
    {
        year: "2016",
        degree: "BACHELOR DEGREE - Informatics Engineering",
        institute: "Universitas Budi Luhur"
    }
];
const Education = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        children: educationContent.map((val, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "icon",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fa fa-briefcase"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "time open-sans-font text-uppercase",
                        children: val.year
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h5", {
                        className: "poppins-font text-uppercase",
                        children: [
                            val.degree,
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "place open-sans-font",
                                children: val.institute
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "open-sans-font",
                        children: val.details
                    })
                ]
            }, i))
    });
};
/* harmony default export */ const about_Education = (Education);

;// CONCATENATED MODULE: ./src/components/about/Experience.jsx


const experienceContent = [
    {
        year: "   2019 - Present",
        position: "Front-End Developer",
        companyName: "PT. Binc Teknologi Grup",
        details: "Develop Maintenance Web Analisa.io & Develop Web Hawksight.co"
    },
    {
        year: "2017 - 2018",
        position: "Front-End Developer",
        companyName: "PT. Altavindo",
        details: "Develop Maintenance Web JKT48.com & Maintenance Web Mandirikartukredit.com"
    }
];
const Experience = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        children: experienceContent.map((val, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "icon",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fa fa-briefcase"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "time open-sans-font text-uppercase",
                        children: val.year
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h5", {
                        className: "poppins-font text-uppercase",
                        children: [
                            val.position,
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "place open-sans-font",
                                children: val.companyName
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "open-sans-font",
                        children: val.details
                    })
                ]
            }, i))
    });
};
/* harmony default export */ const about_Experience = (Experience);

;// CONCATENATED MODULE: ./src/components/about/PersonalInfo.jsx


const personalInfoContent = [
    {
        meta: "Name",
        metaInfo: "Mohammad Ardi Iradat",
        hasColor: ""
    },
    {
        meta: "Age",
        metaInfo: "28 Years",
        hasColor: ""
    },
    {
        meta: "Freelance",
        metaInfo: "Available",
        hasColor: "green"
    },
    {
        meta: "Address",
        metaInfo: "Banten, Indonesia",
        hasColor: ""
    },
    {
        meta: "Email",
        metaInfo: "ardi.iradat@gmail.com",
        hasColor: ""
    },
    {
        meta: "Languages",
        metaInfo: "Bahasa & English",
        hasColor: ""
    }
];
const PersonalInfo = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: "about-list list-unstyled open-sans-font",
        children: personalInfoContent.map((val, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "title",
                        children: [
                            val.meta,
                            ": "
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: `value d-block d-sm-inline-block d-lg-block d-xl-inline-block ${val.hasColor}`,
                        children: val.metaInfo
                    })
                ]
            }, i))
    });
};
/* harmony default export */ const about_PersonalInfo = (PersonalInfo);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/about/Skills.jsx



const skillsContent = [
    {
        img: "/assets/img/skills/html5.png",
        skillName: "HTML",
        padding: "0",
        filter: "grayscale(1)"
    },
    {
        img: "/assets/img/skills/sass.png",
        skillName: "SASS",
        padding: "14px 0",
        filter: "grayscale(1)"
    },
    {
        img: "/assets/img/skills/jquery.png",
        skillName: "JQUERY",
        padding: "4px 0",
        filter: "grayscale(1)"
    },
    {
        img: "/assets/img/skills/javascript.png",
        skillName: "JAVASCRIPT",
        padding: "3px 0",
        filter: "grayscale(1)"
    },
    {
        img: "/assets/img/skills/bootstrap.png",
        skillName: "BOOTSTRAP",
        padding: "10px 0",
        filter: "grayscale(1)"
    },
    {
        img: "/assets/img/skills/tailwind.png",
        skillName: "TAILWIND",
        padding: "0",
        filter: "grayscale(1)"
    },
    {
        img: "/assets/img/skills/nextjs.png",
        skillName: "NEXTJS",
        padding: "19.5px 0",
        filter: "contrast(0)"
    },
    {
        img: "/assets/img/skills/react.png",
        skillName: "REACTJS",
        padding: "1.5px 0",
        filter: "grayscale(1)"
    }
];
const Skills = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: skillsContent.map((val, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "col-6 col-md-3 mb-3 mb-sm-5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-100 d-flex justify-content-center",
                        style: {
                            padding: val.padding,
                            filter: val.filter
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: val.img,
                            alt: "image icon skills",
                            style: {
                                width: "100px"
                            }
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                        className: "text-uppercase open-sans-font text-center mt-2 mt-sm-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("b", {
                            children: val.skillName
                        })
                    })
                ]
            }, i))
    });
};
/* harmony default export */ const about_Skills = (Skills);

;// CONCATENATED MODULE: ./public/assets/img/cv.webp
/* harmony default export */ const cv = ({"src":"/_next/static/media/cv.8d18d6ce.webp","height":570,"width":440,"blurDataURL":"data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAADwAQCdASoGAAgAAkA4JaQAAueG5J524AAA/uev/u31nxJH/WrQw1mCGuHVjZAA","blurWidth":6,"blurHeight":8});
// EXTERNAL MODULE: ./public/assets/img/hero/img-mobile.jpg
var img_mobile = __webpack_require__(6029);
;// CONCATENATED MODULE: ./src/components/about/index.jsx










const index = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "main-content ",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-6 col-lg-5 col-12",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-12",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-uppercase custom-title mb-0 ft-wt-600",
                                            children: "personal infos"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-12 d-block d-sm-none",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: img_mobile/* default */.Z,
                                            className: "img-fluid main-img-mobile",
                                            alt: "about avatar"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-12",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(about_PersonalInfo, {})
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xl-6 col-lg-7 col-12 mt-5 mt-lg-0",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(about_Achievements, {})
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                    className: "separator"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "text-uppercase pb-4 pb-sm-5 mb-3 mb-sm-0 text-start text-sm-center custom-title ft-wt-600",
                                children: "My Skills"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(about_Skills, {})
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                    className: "separator mt-1"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                className: "text-uppercase pb-5 mb-0 text-start text-sm-center custom-title ft-wt-600",
                                children: [
                                    "Experience ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "&"
                                    }),
                                    " Education"
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6 m-15px-tb",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "resume-box",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(about_Experience, {})
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6 m-15px-tb",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "resume-box",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(about_Education, {})
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const about = (index);


/***/ }),

/***/ 3192:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9931);
/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_modal__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_assets_img_hero_img_mobile_jpg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6029);
/* harmony import */ var _public_assets_img_cancel_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4275);
/* harmony import */ var _about__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(201);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_6__);







const heroContent = {
    heroImage: "/assets/img/hero/dark.jpg",
    heroMobileImage: _public_assets_img_hero_img_mobile_jpg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
    heroTitleName: "Ardi Iradat",
    heroDesignation: "Front-End Developer",
    heroDescriptions: `I'm Front‑End developer & Web Designer focused on
  built clean & user‑friendly experiences website, I am passionate about
  building excellent website.`,
    heroBtn: "more about me"
};
const Hero = ()=>{
    const [isOpen, setIsOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    function toggleModalOne() {
        setIsOpen(!isOpen);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row home-details-container align-items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-4 bg position-fixed d-none d-lg-block",
                        style: {
                            backgroundImage: `url(${heroContent.heroImage})`
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12 col-lg-8 offset-lg-4 home-details text-center text-lg-start",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    src: heroContent.heroMobileImage,
                                    className: "img-fluid main-img-mobile d-sm-block d-lg-none",
                                    alt: "hero man"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                    className: "text-uppercase poppins-font",
                                    children: [
                                        "I'm",
                                        " ",
                                        heroContent.heroTitleName,
                                        ".",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: heroContent.heroDesignation
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "open-sans-font",
                                    children: heroContent.heroDescriptions
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    className: "button",
                                    onClick: toggleModalOne,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "button-text",
                                            children: heroContent.heroBtn
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "button-icon fa fa-arrow-right"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_modal__WEBPACK_IMPORTED_MODULE_2___default()), {
                isOpen: isOpen,
                onRequestClose: toggleModalOne,
                contentLabel: "My dialog",
                className: "custom-modal dark hero",
                overlayClassName: "custom-overlay dark",
                closeTimeoutMS: 500,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "close-modal",
                            onClick: toggleModalOne,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                src: _public_assets_img_cancel_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                                alt: "close icon"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "box_inner about",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                "data-aos": "fade-up",
                                "data-aos-duration": "1200",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "title-section text-start text-sm-center",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                children: [
                                                    "ABOUT ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: "ME"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "title-bg",
                                                children: "Resume"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_about__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);


/***/ }),

/***/ 7110:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ portfolio_Portfolio)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
;// CONCATENATED MODULE: ./src/components/portfolio/slider.jsx



function slider() {
    var settings = {
        infinite: true,
        dots: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        fade: true,
        arrows: true
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_slick_default()), {
        ...settings,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-center",
                        children: "Analisa.io"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        target: "_blank",
                        style: {
                            textDecoration: "none"
                        },
                        href: "https://analisa.io",
                        rel: "noreferrer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/assets/img/portfolio/mockup-analisa.png",
                            alt: ""
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-center",
                        children: "Hawksight.co"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        target: "_blank",
                        style: {
                            textDecoration: "none"
                        },
                        href: "https://hawksight.co",
                        rel: "noreferrer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/assets/img/portfolio/mockup-hawksight.png",
                            alt: ""
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-center",
                        children: "MandiriKartuKredit.com"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        target: "_blank",
                        style: {
                            textDecoration: "none"
                        },
                        href: "https://mandirikartukredit.com",
                        rel: "noreferrer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/assets/img/portfolio/mockup-mandiri-kartukredit.png",
                            alt: ""
                        })
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const portfolio_slider = (slider);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./public/assets/img/cancel.svg
var cancel = __webpack_require__(4275);
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-1.jpg
/* harmony default export */ const project_1 = ({"src":"/_next/static/media/project-1.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-2.jpg
/* harmony default export */ const project_2 = ({"src":"/_next/static/media/project-2.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-3.jpg
/* harmony default export */ const project_3 = ({"src":"/_next/static/media/project-3.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-4.jpg
/* harmony default export */ const project_4 = ({"src":"/_next/static/media/project-4.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-5.jpg
/* harmony default export */ const project_5 = ({"src":"/_next/static/media/project-5.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-6.jpg
/* harmony default export */ const project_6 = ({"src":"/_next/static/media/project-6.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-7.jpg
/* harmony default export */ const project_7 = ({"src":"/_next/static/media/project-7.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-8.jpg
/* harmony default export */ const project_8 = ({"src":"/_next/static/media/project-8.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-9.jpg
/* harmony default export */ const project_9 = ({"src":"/_next/static/media/project-9.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/components/portfolio/portfolioData.js









const portfolioData_PortfolioData = [
    {
        id: 1,
        type: "mockup project",
        image: project_1,
        tag: [
            "mockup"
        ],
        delayAnimation: "0",
        modalDetails: [
            {
                project: "Website",
                client: "Envato",
                language: "HTML, CSS, Javascript",
                preview: "www.envato.com",
                link: "https://www.envato.com/"
            }
        ]
    },
    {
        id: 2,
        type: "youtube project",
        image: project_2,
        tag: [
            "video"
        ],
        delayAnimation: "100",
        modalDetails: [
            {
                project: "video",
                client: "Videohive",
                language: " Adobe After Effects",
                preview: "www.videohive.net",
                link: "https://www.videohive.net"
            }
        ]
    },
    {
        id: 3,
        type: "slider project",
        image: project_3,
        tag: [],
        delayAnimation: "200",
        modalDetails: [
            {
                project: "Website",
                client: "Themeforest",
                language: " HTML, CSS, Javascript",
                preview: "www.envato.com",
                link: "https://www.envato.com"
            }
        ]
    },
    {
        id: 4,
        type: "local project",
        image: project_4,
        tag: [
            "logo",
            "video"
        ],
        delayAnimation: "0",
        modalDetails: [
            {
                project: "video",
                client: "Videohive",
                language: " Adobe After Effects",
                preview: "www.videohive.net",
                link: "https://www.videohive.net"
            }
        ]
    },
    {
        id: 5,
        type: "saas project",
        image: project_5,
        tag: [
            "logo"
        ],
        delayAnimation: "100",
        modalDetails: [
            {
                project: "Web Application",
                client: "Themeforest",
                language: "HTML, CSS, ReactJS",
                preview: "www.envato.com",
                link: "https://themeforest.net/item/deski-saas-software-react-template/33799794"
            }
        ]
    },
    {
        id: 6,
        type: "mockup project",
        image: project_6,
        tag: [
            "logo",
            "mockup"
        ],
        delayAnimation: "200",
        modalDetails: [
            {
                project: "Website",
                client: "Themeforest",
                language: "HTML, CSS, Javascript",
                preview: "www.pexels.com",
                link: "https://www.pexels.com"
            }
        ]
    },
    {
        id: 7,
        type: "facebook project",
        image: project_7,
        tag: [
            "logo"
        ],
        delayAnimation: "0",
        modalDetails: [
            {
                project: "Website",
                client: "Facebook",
                language: "HTML, CSS, Javascript",
                preview: "www.facebook.com",
                link: "https://www.facebook.com/ibthemes"
            }
        ]
    },
    {
        id: 8,
        type: "dribble project",
        image: project_8,
        tag: [
            "graphic design"
        ],
        delayAnimation: "100",
        modalDetails: [
            {
                project: "Website",
                client: "Dribbble",
                language: "HTML, CSS, Javascript",
                preview: "www.dribbble.com",
                link: "https://dribbble.com/ib-themes"
            }
        ]
    },
    {
        id: 9,
        type: "behence project",
        image: project_9,
        tag: [
            "graphic design",
            "mockup"
        ],
        delayAnimation: "200",
        modalDetails: [
            {
                project: "Website",
                client: "Behance",
                language: "HTML, CSS, Javascript",
                preview: "www.behance.com",
                link: "https://www.behance.net/ib-themes"
            }
        ]
    }
];
/* harmony default export */ const portfolioData = ((/* unused pure expression or super */ null && (portfolioData_PortfolioData)));

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalOne.jsx





const ModalOne_ModalOne = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: "modal_portfolio ",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ _jsx("div", {}),
            /*#__PURE__*/ _jsx("div", {
                className: "modal__content",
                children: PortfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    return /*#__PURE__*/ _jsxs("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ _jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ _jsxs("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ _jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: item.image,
                                    alt: "portfolio project demo"
                                })
                            }),
                            /*#__PURE__*/ _jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: CloseImg,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalOne = ((/* unused pure expression or super */ null && (ModalOne_ModalOne)));

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalTwo.jsx





const ModalTwo_ModalTwo = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "modal__content",
                children: PortfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    return /*#__PURE__*/ _jsxs("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ _jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ _jsxs("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ _jsx("figure", {
                                className: "modal__img videocontainer",
                                children: /*#__PURE__*/ _jsx("iframe", {
                                    src: "https://www.youtube.com/embed/7e90gBu4pas",
                                    title: "YouTube video player",
                                    className: "youtube-video",
                                    allowFullScreen: true
                                })
                            }),
                            /*#__PURE__*/ _jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: CloseImg,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalTwo = ((/* unused pure expression or super */ null && (ModalTwo_ModalTwo)));

// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick.css
var slick = __webpack_require__(8278);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick-theme.css
var slick_theme = __webpack_require__(782);
;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalThree.jsx
// external






// internal




const ModalThree_ModalThree = ({ modalId , setGetModal  })=>{
    let settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        draggable: true
    };
    return /*#__PURE__*/ _jsxs("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "modal__content",
                children: PortfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ _jsxs("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ _jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ _jsxs("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ _jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ _jsxs(Slider, {
                                    ...settings,
                                    children: [
                                        /*#__PURE__*/ _jsx("div", {
                                            children: /*#__PURE__*/ _jsx(Image, {
                                                src: item.image,
                                                alt: "portfolio project demo"
                                            })
                                        }),
                                        /*#__PURE__*/ _jsx("div", {
                                            children: /*#__PURE__*/ _jsx(Image, {
                                                src: img1,
                                                alt: "portfolio project demo"
                                            })
                                        }),
                                        /*#__PURE__*/ _jsx("div", {
                                            children: /*#__PURE__*/ _jsx(Image, {
                                                src: img2,
                                                alt: "portfolio project demo"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ _jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: CloseImg,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalThree = ((/* unused pure expression or super */ null && (ModalThree_ModalThree)));

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalFour.jsx





const ModalFour_ModalFour = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "modal__content",
                children: PortfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ _jsxs("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ _jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ _jsxs("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ _jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ _jsx("video", {
                                    id: "video",
                                    className: "responsive-video",
                                    controls: true,
                                    poster: item.image,
                                    children: /*#__PURE__*/ _jsx("source", {
                                        src: "/assets/img/portfolio/video.mp4",
                                        type: "video/mp4"
                                    })
                                })
                            }),
                            /*#__PURE__*/ _jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: CloseImg,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalFour = ((/* unused pure expression or super */ null && (ModalFour_ModalFour)));

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalFive.jsx





const ModalFive_ModalFive = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "modal__content",
                children: PortfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ _jsxs("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ _jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ _jsxs("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ _jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: item.image,
                                    alt: "portfolio project demo"
                                })
                            }),
                            /*#__PURE__*/ _jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: CloseImg,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalFive = ((/* unused pure expression or super */ null && (ModalFive_ModalFive)));

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalSix.jsx





const ModalSix_ModalSix = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "modal__content",
                children: PortfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ _jsxs("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ _jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ _jsxs("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ _jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: item.image,
                                    alt: "portfolio project demo"
                                })
                            }),
                            /*#__PURE__*/ _jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: CloseImg,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalSix = ((/* unused pure expression or super */ null && (ModalSix_ModalSix)));

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalSeven.jsx





const ModalSeven_ModalSeven = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "modal__content",
                children: PortfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ _jsxs("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ _jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ _jsxs("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ _jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: item.image,
                                    alt: "portfolio project demo"
                                })
                            }),
                            /*#__PURE__*/ _jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: CloseImg,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalSeven = ((/* unused pure expression or super */ null && (ModalSeven_ModalSeven)));

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalEight.jsx





const ModalEight_ModalEight = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "modal__content",
                children: PortfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ _jsxs("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ _jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ _jsxs("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ _jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: item.image,
                                    alt: "portfolio project demo"
                                })
                            }),
                            /*#__PURE__*/ _jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: CloseImg,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalEight = ((/* unused pure expression or super */ null && (ModalEight_ModalEight)));

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalNine.jsx





const ModalNine_ModalNine = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "modal__content",
                children: PortfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ _jsxs("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ _jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ _jsxs("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ _jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ _jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ _jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: item.image,
                                    alt: "portfolio project demo"
                                })
                            }),
                            /*#__PURE__*/ _jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ _jsx(Image, {
                                    src: CloseImg,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalNine = ((/* unused pure expression or super */ null && (ModalNine_ModalNine)));

;// CONCATENATED MODULE: ./src/components/portfolio/modal/ModalMain.jsx











const ModalMain = ({ modalId , setGetModal  })=>{
    if (modalId === 1) {
        return /*#__PURE__*/ _jsx(ModalOne, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 2) {
        return /*#__PURE__*/ _jsx(ModalTwo, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 3) {
        return /*#__PURE__*/ _jsx(ModalThree, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 4) {
        return /*#__PURE__*/ _jsx(ModalFour, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 5) {
        return /*#__PURE__*/ _jsx(ModalFive, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 6) {
        return /*#__PURE__*/ _jsx(ModalSix, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 7) {
        return /*#__PURE__*/ _jsx(ModalSeven, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 8) {
        return /*#__PURE__*/ _jsx(ModalEight, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 9) {
        return /*#__PURE__*/ _jsx(ModalNine, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    }
};
/* harmony default export */ const modal_ModalMain = ((/* unused pure expression or super */ null && (ModalMain)));

;// CONCATENATED MODULE: ./src/components/portfolio/Portfolio.jsx




const Portfolio = ()=>{
    const [getModal, setGetModal] = (0,external_react_.useState)(false);
    const [modalId, setModalId] = (0,external_react_.useState)(1);
    const handleModal = (id)=>{
        setGetModal(true);
        setModalId(id);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "portfolio-main m-auto",
            style: {
                width: "60%"
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx(portfolio_slider, {})
        })
    });
};
/* harmony default export */ const portfolio_Portfolio = (Portfolio);


/***/ }),

/***/ 1281:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ switch_SwitchDark)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/assets/img/sun.png
/* harmony default export */ const sun = ({"src":"/_next/static/media/sun.e8a19ea6.png","height":24,"width":24,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAASklEQVR42l2NwQ2AMAzEHB4VI5SVskI3yMrtLmCJRxFyHvFJl8BBACkQmlM0LmmUBpwMlgw3IOnKLcstv8HEYFfmW9lHu1oE/7cPkP0RT+u5jqgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./utils/theme.js
function handleSwitchValue(value) {
    if (value) {
        localStorage.setItem("theme-color", "dark");
        document.querySelector("body").classList.add("dark");
        document.querySelector("body").classList.remove("light");
    } else {
        localStorage.setItem("theme-color", "light");
        document.querySelector("body").classList.add("light");
        document.querySelector("body").classList.remove("dark");
    }
}
/* harmony default export */ const theme = (handleSwitchValue);

;// CONCATENATED MODULE: ./src/components/switch/SwitchDark.jsx





const SwitchDark = ()=>{
    const [isDark, setIsDark] = (0,external_react_.useState)(false);
    const handleLabelClick = ()=>{
        if (isDark) {
            theme(true);
            setIsDark(false);
        } else {
            theme(false);
            setIsDark(true);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
        className: `theme-switcher-label d-flex  ${isDark ? "active" : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "checkbox",
                onClick: handleLabelClick,
                className: "theme-switcher"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "switch-handle",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "light-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: sun,
                            alt: "swicher",
                            className: "filter_1",
                            priority: true
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "dark-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fa fa-moon-o",
                            "aria-hidden": "true"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const switch_SwitchDark = (SwitchDark);


/***/ }),

/***/ 5532:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_2__]);
react_toastify__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Wrapper = ({ children  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Wrapper);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9610:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5973);
/* harmony import */ var react_tabs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_tabs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_hero_Hero__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3192);
/* harmony import */ var _components_about__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(201);
/* harmony import */ var _layout_wrapper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5532);
/* harmony import */ var _components_Seo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1690);
/* harmony import */ var _components_portfolio_Portfolio__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7110);
/* harmony import */ var _components_Address__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8212);
/* harmony import */ var _components_Social__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9830);
/* harmony import */ var _components_Contact__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6047);
/* harmony import */ var _components_switch_SwitchDark__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1281);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_wrapper__WEBPACK_IMPORTED_MODULE_5__, _components_Contact__WEBPACK_IMPORTED_MODULE_10__]);
([_layout_wrapper__WEBPACK_IMPORTED_MODULE_5__, _components_Contact__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const menuItem = [
    {
        icon: "fa-home",
        menuName: "Home"
    },
    {
        icon: "fa-regular fa-user",
        menuName: "About"
    },
    {
        icon: "fa-briefcase",
        menuName: "Portfolio"
    },
    {
        icon: "fa-envelope-open",
        menuName: "Contact"
    }
];
const HomeDark = ()=>{
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        document.querySelector("body").classList.remove("rtl");
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_layout_wrapper__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Seo__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                pageTitle: "Mohammad Ardi Iradat"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "yellow",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_switch_SwitchDark__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_tabs__WEBPACK_IMPORTED_MODULE_2__.Tabs, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "header",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_tabs__WEBPACK_IMPORTED_MODULE_2__.TabList, {
                                    className: " icon-menu revealator-slideup revealator-once revealator-delay1",
                                    children: menuItem.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_tabs__WEBPACK_IMPORTED_MODULE_2__.Tab, {
                                            className: "icon-box",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    style: {
                                                        zIndex: "10"
                                                    },
                                                    className: `fa ${item.icon}`
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    style: {
                                                        zIndex: "9"
                                                    },
                                                    children: item.menuName
                                                })
                                            ]
                                        }, i))
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "tab-panel_list",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_tabs__WEBPACK_IMPORTED_MODULE_2__.TabPanel, {
                                        className: "home ",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "container-fluid main-container container-home p-0 g-0",
                                            "data-aos": "fade-up",
                                            "data-aos-duration": "1200",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "color-block d-none d-lg-block"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_hero_Hero__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_tabs__WEBPACK_IMPORTED_MODULE_2__.TabPanel, {
                                        className: "about",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            "data-aos": "fade-up",
                                            "data-aos-duration": "1200",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "title-section text-start text-sm-center",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                            children: [
                                                                "ABOUT ",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    children: "ME"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "title-bg",
                                                            children: "Resume"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_tabs__WEBPACK_IMPORTED_MODULE_2__.TabPanel, {
                                        className: "portfolio professional",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "title-section text-start text-sm-center",
                                                "data-aos": "fade-up",
                                                "data-aos-duration": "1200",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                        children: [
                                                            "my ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "portfolio"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "title-bg",
                                                        children: "works"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_portfolio_Portfolio__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_tabs__WEBPACK_IMPORTED_MODULE_2__.TabPanel, {
                                        className: "contact",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "title-section text-start text-sm-center",
                                                "data-aos": "fade-up",
                                                "data-aos-duration": "1200",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                        children: [
                                                            "get in ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: "touch"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "title-bg",
                                                        children: "contact"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "container",
                                                "data-aos": "fade-up",
                                                "data-aos-duration": "1200",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "row",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-12 col-lg-4",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                                                    className: "text-uppercase custom-title mb-0 ft-wt-600 pb-3",
                                                                    children: [
                                                                        "Don't",
                                                                        " be shy !"
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    className: "open-sans-font mb-4",
                                                                    children: "Feel free to get in touch with me. I am always open to discussing new projects, creative ideas or opportunities to be part of your visions."
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Address__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "col-12 col-lg-8",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Contact__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeDark);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;